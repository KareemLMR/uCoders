/*
 * GPIO_priv.h
 *
 *  Created on: ??�/??�/????
 *      Author: 7
 */

#ifndef GPIO_PRIV_H_
#define GPIO_PRIV_H_



#define LED_BUILTIN_RED 100
#define LED_BUILTIN_GREEN 101
#define LED_BUILTIN_BLUE 102


#define IN 0
#define OUT 1



#endif /* GPIO_PRIV_H_ */

/*
 * CLOCKDRIVER.h
 *
 *  Created on: ??�/??�/????
 *      Author: 7
 */

#ifndef CLOCKDRIVER_H_
#define CLOCKDRIVER_H_

//#include "CLK_REGISTERMap.h"



#endif /* CLOCKDRIVER_H_ */

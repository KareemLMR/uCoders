/*
 * GPIO_config.h
 *
 *  Created on: ??�/??�/????
 *      Author: 7
 */

#ifndef GPIO_CONFIG_H_
#define GPIO_CONFIG_H_

#include "GPIO_priv.h"


#define GPIO_PIN0             IN
#define GPIO_PIN1             IN
#define GPIO_PIN2             IN
#define GPIO_PIN3             IN
#define GPIO_PIN4             IN
#define GPIO_PIN5             IN
#define GPIO_PIN6             IN
#define GPIO_PIN7             IN


#define GPIO_PIN8              IN
#define GPIO_PIN9              IN
#define GPIO_PIN10             IN
#define GPIO_PIN11             IN
#define GPIO_PIN12             IN
#define GPIO_PIN13             IN
#define GPIO_PIN14             IN
#define GPIO_PIN15             IN


#define GPIO_PIN16             IN
#define GPIO_PIN17             IN
#define GPIO_PIN18             IN
#define GPIO_PIN19             IN
#define GPIO_PIN20             IN
#define GPIO_PIN21             IN
#define GPIO_PIN22             IN
#define GPIO_PIN23             IN

#define GPIO_PIN24             IN
#define GPIO_PIN25             IN
#define GPIO_PIN26             IN
#define GPIO_PIN27             IN
#define GPIO_PIN28             IN
#define GPIO_PIN29             IN
#define GPIO_PIN30             IN
#define GPIO_PIN31             IN


#define GPIO_PIN32             IN
#define GPIO_PIN33             IN
#define GPIO_PIN34             IN
#define GPIO_PIN35             IN
#define GPIO_PIN36             IN
#define GPIO_PIN37             IN
#define GPIO_PIN38             IN
#define GPIO_PIN39             IN


#define GPIO_PIN40             IN
#define GPIO_PIN41             IN
#define GPIO_PIN42             IN
#define GPIO_PIN43             IN
#define GPIO_PIN44             IN
#define GPIO_PIN45             OUT
#define GPIO_PIN46             OUT
#define GPIO_PIN47             OUT

#endif /* GPIO_CONFIG_H_ */

/*
 * delay.c
 *
 *  Created on: ??�/??�/????
 *      Author: 7
 */
#include"delay.h"

void delay(int period)
{
    long  double numberOfIterations = period * 100000000 * SYSTEM_CLOCK;
    long  double i = 0;
    int j = 0;
    for(i = 0 ; i < period ; i++)
    {

    }
}




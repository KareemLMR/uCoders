/*
 * delay.h
 *
 *  Created on: ??�/??�/????
 *      Author: 7
 */

#ifndef DELAY_H_
#define DELAY_H_

#define SYSTEM_CLOCK          80000000UL
void delay(int);

#endif /* DELAY_H_ */
